This directory contains a list of scenarios (different combinations of Kustomize Components) used for testing.
See [/.github/workflows/kustomize-build-ci.yaml](../../.github/workflows/kustomize-build-ci.yaml).
